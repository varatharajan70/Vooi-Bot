from colorama import *

red = Fore.LIGHTRED_EX
cyan = Fore.LIGHTCYAN_EX
magenta = Fore.LIGHTMAGENTA_EX
green = Fore.LIGHTGREEN_EX
black = Fore.LIGHTBLACK_EX
yellow = Fore.LIGHTYELLOW_EX
white = Fore.LIGHTWHITE_EX
blue = Fore.LIGHTBLUE_EX
reset = Style.RESET_ALL

banner = f"""

{cyan}db   dD .d888b.   d8888b. d8888b.  .d88b.     d88b d88888b  .o88b. d888888b 
{cyan}88 ,8P' 88' `8D   88  `8D 88  `8D .8P  Y8.    `8P' 88'     d8P  Y8 `~~88~~' {green}Author   : kaimarks9 / {green}VooiApp!
{cyan}88,8P   `V8o88'   88oodD' 88oobY' 88    88     88  88ooooo 8P         88    {cyan}Github   : {yellow}@kaimarks9
{cyan}88`8b      d8'    88~~~   88`8b   88    88     88  88~~~~~ 8b         88    {red}Notes    : Your doing is your respondbility!
{cyan}88 `88.   d8'     88      88 `88. `8b  d8' db. 88  88.     Y8b  d8    88    {yellow}Warning  : this is for education purpose only!
{cyan}YP   YD  d8'      88      88   YD  `Y88P'  Y8888P  Y88888P  `Y88P'    YP    

"""